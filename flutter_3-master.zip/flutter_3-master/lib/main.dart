import 'package:flutter/material.dart';
import 'package:screens/home.dart';
void main() {
  runApp(
      const MaterialApp(
        title:'Interactive Screen',
        home: Home(),
        debugShowCheckedModeBanner: false,
      )
  );
}
